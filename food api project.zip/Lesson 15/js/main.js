const container = document.querySelector(".container")
const box = document.querySelector(".card")
const title = document.querySelector(".h2")
const para = document.querySelector(".p")
const text = document.querySelector(".button")


const api_links = "https://jsonplaceholder.typicode.com/posts"
const body = document.querySelector(".body")

const getData = async (api)=>{
    const req = await fetch(api)
    const data = await req.json()

    data.forEach(item => {
        console.log(item.title);
        container.innerHTML += 
        `<div class="card">
            <h2 class="h2">${item.title}</h2>
            <p class="p">${item.body}</p>
            <button class="button">${item.id}</button>
        </div>`
    });
}

getData(api_links)